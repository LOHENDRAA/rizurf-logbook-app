---
name: Precision Developer Canvas
colors:
  surface: '#f8f9ff'
  surface-dim: '#cbdbf5'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eff4ff'
  surface-container: '#e5eeff'
  surface-container-high: '#dce9ff'
  surface-container-highest: '#d3e4fe'
  on-surface: '#0b1c30'
  on-surface-variant: '#434655'
  inverse-surface: '#213145'
  inverse-on-surface: '#eaf1ff'
  outline: '#737686'
  outline-variant: '#c3c6d7'
  surface-tint: '#0053db'
  primary: '#004ac6'
  on-primary: '#ffffff'
  primary-container: '#2563eb'
  on-primary-container: '#eeefff'
  inverse-primary: '#b4c5ff'
  secondary: '#565e74'
  on-secondary: '#ffffff'
  secondary-container: '#dae2fd'
  on-secondary-container: '#5c647a'
  tertiary: '#9a3100'
  on-tertiary: '#ffffff'
  tertiary-container: '#c34100'
  on-tertiary-container: '#ffede8'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dbe1ff'
  primary-fixed-dim: '#b4c5ff'
  on-primary-fixed: '#00174b'
  on-primary-fixed-variant: '#003ea8'
  secondary-fixed: '#dae2fd'
  secondary-fixed-dim: '#bec6e0'
  on-secondary-fixed: '#131b2e'
  on-secondary-fixed-variant: '#3f465c'
  tertiary-fixed: '#ffdbcf'
  tertiary-fixed-dim: '#ffb59b'
  on-tertiary-fixed: '#380d00'
  on-tertiary-fixed-variant: '#822800'
  background: '#f8f9ff'
  on-background: '#0b1c30'
  surface-variant: '#d3e4fe'
  surface-pure: '#FFFFFF'
  surface-subtle: '#F8FAFC'
  surface-muted: '#F1F5F9'
  border-subtle: '#E2E8F0'
  border-strong: '#CBD5E1'
  text-primary: '#0F172A'
  text-secondary: '#334155'
  text-tertiary: '#64748B'
  accent-electric: '#1D4ED8'
  accent-cyan: '#0284C7'
  code-badge-bg: '#F8FAFC'
typography:
  display:
    fontFamily: Plus Jakarta Sans
    fontSize: 3.5rem
    fontWeight: '700'
    lineHeight: '1.1'
    letterSpacing: -0.03em
  display-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 2.5rem
    fontWeight: '700'
    lineHeight: '1.15'
    letterSpacing: -0.025em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 2.25rem
    fontWeight: '600'
    lineHeight: '1.2'
    letterSpacing: -0.025em
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 1.75rem
    fontWeight: '600'
    lineHeight: '1.25'
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 1.5rem
    fontWeight: '600'
    lineHeight: '1.3'
    letterSpacing: -0.02em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 1.25rem
    fontWeight: '600'
    lineHeight: '1.35'
    letterSpacing: -0.015em
  body-lg:
    fontFamily: Inter
    fontSize: 1.125rem
    fontWeight: '400'
    lineHeight: '1.6'
    letterSpacing: -0.01em
  body-md:
    fontFamily: Inter
    fontSize: 0.9375rem
    fontWeight: '400'
    lineHeight: '1.55'
    letterSpacing: -0.005em
  body-sm:
    fontFamily: Inter
    fontSize: 0.8125rem
    fontWeight: '400'
    lineHeight: '1.5'
    letterSpacing: 0em
  label-md:
    fontFamily: Inter
    fontSize: 0.875rem
    fontWeight: '500'
    lineHeight: '1.25'
    letterSpacing: 0em
  label-sm:
    fontFamily: Inter
    fontSize: 0.75rem
    fontWeight: '600'
    lineHeight: '1.2'
    letterSpacing: 0.02em
  code-md:
    fontFamily: JetBrains Mono
    fontSize: 0.875rem
    fontWeight: '500'
    lineHeight: '1.4'
    letterSpacing: -0.01em
  code-sm:
    fontFamily: JetBrains Mono
    fontSize: 0.75rem
    fontWeight: '500'
    lineHeight: '1.4'
    letterSpacing: 0em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-sm: 1rem
  margin: 2rem
  margin-sm: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

The design system embodies a modern developer-tool aesthetic: surgical, fast, deterministic, and refined. Designed for engineers, technical operators, and product builders who demand instantaneous legibility and dense functional utility without visual clutter. The emotional tone is authoritative yet frictionless—evoking the tactile precision of high-end developer documentation, terminal outputs, and robust API platforms.

The style synthesizes modern utility minimalism with subtle structural borders and micro-depth. Surfaces rely on pure crisp whites stacked upon slate-tinted foundation layers, bounded by razor-thin borders and micro-chamfered corners. Accents are deliberate and electrifying, using sharp royal and cobalt blues paired with intentional monospace technical cues to indicate state, execution latency, and data fidelity.

## Colors

The color architecture is built around a pure-light foundation calibrated for prolonged cognitive focus. 

- **Primary (`#2563EB`)**: High-saturation electric cobalt blue used exclusively for primary calls to action, focus outlines, key interactive indicators, and active workflow states.
- **Secondary (`#0F172A`)**: Deep pitch slate representing highest typography hierarchy, terminal backdrops, and high-impact structural blocks.
- **Tertiary (`#FA5D19`)**: A fiery amber-orange retained from performance benchmarking and real-time execution alerts, reserved for live status indicators, warnings, and highlighting latency outliers.
- **Neutral (`#64748B`)**: Balanced cool zinc/slate governing secondary labels, structural division, inactive icons, and metadata tags.

### Surface and Canvas Distribution
Backgrounds rely on `#FFFFFF` for primary cards and content panes, set over `#F8FAFC` canvas roots and `#F1F5F9` segmented controls. Boundaries are defined by `#E2E8F0` hairline borders rather than heavy tonal shifts, maintaining a surgical, airy interface.

## Typography

The typography strategy leverages a clear functional dichotomy:

- **Display & Headings (Plus Jakarta Sans)**: Delivers a clean, modern, slightly tech-forward presence with tailored geometric curves and negative letter-spacing for razor-sharp executive polish.
- **Interface & Reading (Inter)**: Handles complex data layouts, tables, forms, and general body text with maximum legibility and tall x-height.
- **Data, Tokens & Telemetry (JetBrains Mono)**: Highlights code snippets, API endpoints, JSON payloads, latency metrics, and version badges. 

All headings use tightened tracking (`-0.015em` to `-0.03em`) to eliminate visual loose ends across high-resolution displays.

## Layout & Spacing

The layout is built on a responsive 12-column grid system bounded by a max structural container width of `1280px` for standard applications and `1440px` for technical dashboards and analytics panes. 

- **Desktop (1024px+)**: 12 columns, `1.5rem` gutters, `2rem` margins. Nested dashboard panes snap to structured 240px/280px sidebars with fluid main canvas panels.
- **Tablet (768px - 1023px)**: 8 columns, `1rem` gutters, `1.5rem` outer margins. Side panels fold into collapsibles or drawer flyouts.
- **Mobile (<768px)**: 4 columns, `0.75rem` to `1rem` gutters, `1rem` outer canvas padding. Grids collapse into vertical single-column stacks with edge-to-edge sub-containers where appropriate.

Component rhythm adheres to a strict 4px/8px incremental base, preventing irregular vertical offsets across dense terminal ribbons and complex form fields.

## Elevation & Depth

Visual hierarchy uses crisp boundary containment over heavy blurred shadows. Depth is achieved via **tonal layering combined with micro-diffused ambient drop shadows**:

- **Layer 0 (Canvas Base)**: `#F8FAFC`, non-elevated ground plane.
- **Layer 1 (Card & Content Panes)**: `#FFFFFF` surface with a 1px solid `#E2E8F0` border and a feather-light shadow: `0 1px 2px 0 rgba(15, 23, 42, 0.04)`.
- **Layer 2 (Dropdowns, Menus, Hovered Cards)**: `#FFFFFF` surface, 1px solid `#CBD5E1` border, backed by a dual shadow: `0 4px 6px -1px rgba(15, 23, 42, 0.06), 0 2px 4px -2px rgba(15, 23, 42, 0.04)`.
- **Layer 3 (Modals, Overlays, Floating Command Palettes)**: `#FFFFFF` surface, 1px solid `#E2E8F0` border, elevated by `0 20px 25px -5px rgba(15, 23, 42, 0.08), 0 8px 10px -6px rgba(15, 23, 42, 0.04)`.

All elevated surfaces maintain deliberate 1px outline definitions to retain crisp demarcation even under variable monitor contrast calibrations.

## Shapes

The design system enforces a soft, disciplined geometry (`roundedness: 1`). Elements are neither aggressively boxy nor overly bulbous:

- Base inputs, buttons, chips, and small controls use `0.375rem` (`6px`) to `0.5rem` (`8px`) corner radii.
- Cards, code snippets, and modal panels use `0.5rem` (`8px`) to `0.75rem` (`12px`) radii.
- Inner elements nested within cards maintain a proportional radius delta (inner radius = outer radius minus container padding) to prevent concentric distortion.

## Components

### Buttons
- **Primary**: Background `#2563EB`, text `#FFFFFF`, 1px border `#1D4ED8`, subtle inner top-edge highlight `inset 0 1px 0 rgba(255, 255, 255, 0.2)`. Hover: `#1D4ED8`. Focus: 2px offset ring with `#2563EB`.
- **Secondary / Neutral**: Background `#FFFFFF`, text `#0F172A`, 1px border `#E2E8F0`. Hover: background `#F8FAFC`, border `#CBD5E1`.
- **Tertiary / Ghost**: Transparent background, text `#334155`. Hover: background `#F1F5F9`, text `#0F172A`.

### Inputs & Search Bars
- Background `#FFFFFF`, 1px solid border `#E2E8F0`, padding `0.5rem 0.75rem`, text `#0F172A`, placeholder `#94A3B8`.
- Focus state: Border color changes to `#2563EB` paired with an electric focus glow ring `0 0 0 3px rgba(37, 99, 235, 0.12)`.
- Includes leading or trailing keyboard shortcuts (e.g., `⌘K`) rendered in JetBrains Mono (`code-sm`) inside a `#F1F5F9` sub-capsule.

### Cards & Content Containers
- Base background `#FFFFFF`, border `1px solid #E2E8F0`, corner radius `0.5rem`.
- Header areas feature a subtle horizontal divider line (`#E2E8F0`) with section labels set in medium weight Inter (`label-md`).

### Chips & Badges
- **Status Badges**: Pill-shaped or `rounded-sm` with `0.25rem 0.5rem` padding.
  - Active/Success: `#ECFDF5` background, `#059669` text, `#A7F3D0` border.
  - Latency/Metric: `#F8FAFC` background, `#334155` text, `#E2E8F0` border, set in JetBrains Mono.
  - Urgent/Alert: `#FFF7ED` background, `#C2410C` text, `#FFEDD5` border.

### Checkboxes & Radios
- Box size `16px x 16px`, border `1px solid #CBD5E1`, background `#FFFFFF`, radius `4px` (checkbox) or `9999px` (radio).
- Checked: Background `#2563EB`, border `#2563EB`, white vector checkmark icon.

### Code Blocks & Telemetry Displays
- Background `#0F172A` (dark contrast accent) or pure white with `#F1F5F9` framing.
- Syntax highlighting keyed against cool slates, electric blue `#38BDF8`, and amber `#FB923C`.
- Includes integrated copy action button pinned to the upper right with micro-tooltip confirmation.