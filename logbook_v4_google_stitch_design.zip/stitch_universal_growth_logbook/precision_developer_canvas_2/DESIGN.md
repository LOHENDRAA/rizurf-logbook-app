---
name: Precision Developer Canvas
colors:
  surface: '#f8f9ff'
  surface-dim: '#cbdbf5'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eff4ff'
  surface-container: '#e5eeff'
  surface-container-high: '#dce9ff'
  surface-container-highest: '#d3e4fe'
  on-surface: '#0b1c30'
  on-surface-variant: '#434655'
  inverse-surface: '#213145'
  inverse-on-surface: '#eaf1ff'
  outline: '#737686'
  outline-variant: '#c3c6d7'
  surface-tint: '#0053db'
  primary: '#004ac6'
  on-primary: '#ffffff'
  primary-container: '#2563eb'
  on-primary-container: '#eeefff'
  inverse-primary: '#b4c5ff'
  secondary: '#565e74'
  on-secondary: '#ffffff'
  secondary-container: '#dae2fd'
  on-secondary-container: '#5c647a'
  tertiary: '#9a3100'
  on-tertiary: '#ffffff'
  tertiary-container: '#c34100'
  on-tertiary-container: '#ffede8'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dbe1ff'
  primary-fixed-dim: '#b4c5ff'
  on-primary-fixed: '#00174b'
  on-primary-fixed-variant: '#003ea8'
  secondary-fixed: '#dae2fd'
  secondary-fixed-dim: '#bec6e0'
  on-secondary-fixed: '#131b2e'
  on-secondary-fixed-variant: '#3f465c'
  tertiary-fixed: '#ffdbcf'
  tertiary-fixed-dim: '#ffb59b'
  on-tertiary-fixed: '#380d00'
  on-tertiary-fixed-variant: '#822800'
  background: '#f8f9ff'
  on-background: '#0b1c30'
  surface-variant: '#d3e4fe'
  surface-canvas: '#F8FAFC'
  surface-card: '#FFFFFF'
  surface-subtle: '#F1F5F9'
  border-subtle: '#E2E8F0'
  border-strong: '#CBD5E1'
  accent-electric: '#1D4ED8'
  accent-cyan: '#0284C7'
  code-badge-bg: '#F8FAFC'
typography:
  display:
    fontFamily: Plus Jakarta Sans
    fontSize: 3.5rem
    fontWeight: '700'
    lineHeight: '1.1'
    letterSpacing: -0.03em
  display-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 2.5rem
    fontWeight: '700'
    lineHeight: '1.15'
    letterSpacing: -0.025em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 2.25rem
    fontWeight: '600'
    lineHeight: '1.2'
    letterSpacing: -0.025em
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 1.75rem
    fontWeight: '600'
    lineHeight: '1.25'
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 1.5rem
    fontWeight: '600'
    lineHeight: '1.3'
    letterSpacing: -0.02em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 1.25rem
    fontWeight: '600'
    lineHeight: '1.35'
    letterSpacing: -0.015em
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 1.125rem
    fontWeight: '400'
    lineHeight: '1.6'
    letterSpacing: -0.01em
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 0.9375rem
    fontWeight: '400'
    lineHeight: '1.55'
    letterSpacing: -0.005em
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 0.8125rem
    fontWeight: '400'
    lineHeight: '1.5'
    letterSpacing: 0em
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 0.875rem
    fontWeight: '500'
    lineHeight: '1.25'
    letterSpacing: 0em
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 0.75rem
    fontWeight: '600'
    lineHeight: '1.2'
    letterSpacing: 0.02em
  code-md:
    fontFamily: JetBrains Mono
    fontSize: 0.875rem
    fontWeight: '500'
    lineHeight: '1.4'
    letterSpacing: -0.01em
  code-sm:
    fontFamily: JetBrains Mono
    fontSize: 0.75rem
    fontWeight: '500'
    lineHeight: '1.4'
    letterSpacing: 0em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-sm: 1rem
  margin: 2rem
  margin-sm: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

The design system embodies a modern developer-tool aesthetic: surgical, fast, deterministic, and refined. Designed for engineers, technical operators, and product teams who demand immediate legibility, high data density, and functional utility without visual friction. The emotional tone is authoritative, clean, and reliable—evoking the tactile precision of high-end developer documentation, terminal outputs, and robust API platforms.

The style synthesizes modern utility minimalism with low-contrast structural borders and micro-depth. Surfaces rely on crisp whites stacked upon slate-tinted foundation layers, bounded by razor-thin borders and disciplined corner radii. Accents are deliberate and electrifying, using sharp royal and cobalt blues paired with an absolute typographic dichotomy: clean geometric sans for UI and human language, alongside crisp monospaced glyphs strictly reserved for technical data, hashes, telemetry, and code.

## Colors

The color architecture is built around a pure-light foundation calibrated for prolonged cognitive focus and dense readability:

- **Primary (`#2563EB`)**: High-saturation electric cobalt blue used exclusively for primary actions, focus rings, active interactive tabs, and system confirmations.
- **Secondary (`#0F172A`)**: Deep pitch slate representing highest typography hierarchy, terminal backdrops, and high-impact structural blocks.
- **Tertiary (`#FA5D19`)**: Fiery amber-orange reserved for execution latency warnings, live status indicators, telemetry outliers, and active alert markers.
- **Neutral (`#64748B`)**: Balanced cool zinc/slate governing secondary labels, structural division, inactive icons, and metadata tags.

Backgrounds rely on `#FFFFFF` for primary cards and content panes, set over `#F8FAFC` canvas roots and `#F1F5F9` segmented controls. Boundaries are defined by `#E2E8F0` hairline borders rather than heavy tonal shifts, maintaining a surgical, airy interface.

## Typography

Typography strictly eliminates all serif and unstandardized typefaces across every viewport, flow, and component:

- **Primary Interface Font (Plus Jakarta Sans)**: Exclusively governs all display titles, headlines, editorial copy, body narrative, form fields, navigation items, buttons, chips, and standard UI badges. Weights are constrained to `400` (Regular), `500` (Medium), `600` (Semi-Bold), and `700` (Bold). Headings enforce tightened tracking (`-0.015em` to `-0.03em`) for a clean, architectural finish.
- **Dedicated Monospace Font (JetBrains Mono)**: Strictly isolated to technical data: commit hashes, git branch identifiers, API payloads, timestamps, latency metrics (`ms`), port numbers, keycode hints (`⌘K`), and developer logs. It is never used for general paragraph text or navigational labels.

## Layout & Spacing

The layout utilizes a 12-column fluid grid system bounded by standard max-width envelopes: `1280px` for standard operational layouts and `1440px` for dense data matrices, trace viewers, and code reviewers.

- **Desktop (1024px+)**: 12 columns with `1.5rem` gutters and `2rem` outer margins. Left navigational sidebars maintain fixed widths (`240px` or `280px`), allowing secondary panels and editor canvases to scale fluidly.
- **Tablet (768px – 1023px)**: 8 columns with `1rem` gutters and `1.5rem` margins. Complex side panels collapse into structured overlay drawers or vertical tabs.
- **Mobile (<768px)**: 4 columns with `1rem` gutters and `1rem` outer canvas padding. Grid items collapse into single-column vertical flows with full-bleed touch targets.

All internal paddings and margins enforce a strict 4px/8px modular rhythm (`space-xs` through `space-xl`) to maintain alignment across terminal ribbons and data cards.

## Elevation & Depth

Elevation eschews heavy theatrical blur in favor of crisp boundary containment and micro-diffused ambient depth:

- **Layer 0 (Canvas Base)**: `#F8FAFC`, non-elevated ground plane.
- **Layer 1 (Cards, Code Blocks, Panels)**: `#FFFFFF` surface with a 1px solid `#E2E8F0` hairline border and an ambient micro-shadow: `0 1px 2px 0 rgba(15, 23, 42, 0.04)`.
- **Layer 2 (Dropdowns, Floating Toolbars, Active Cards)**: `#FFFFFF` surface, 1px solid `#CBD5E1` border, backed by dual depth: `0 4px 6px -1px rgba(15, 23, 42, 0.06), 0 2px 4px -2px rgba(15, 23, 42, 0.04)`.
- **Layer 3 (Modals, Overlays, Command Palettes)**: `#FFFFFF` surface, 1px solid `#E2E8F0` border, elevated by `0 20px 25px -5px rgba(15, 23, 42, 0.08), 0 8px 10px -6px rgba(15, 23, 42, 0.04)`.

Every elevated container maintains an explicit 1px outline to preserve contrast across varied monitor calibrations.

## Shapes

The design system enforces a soft, disciplined geometry (`roundedness: 1`). Radii are calibrated for clean density:

- Base inputs, buttons, status chips, and segmented toggles utilize `0.25rem` (`rounded`) to `0.375rem`.
- Structural cards, telemetry panels, and modal containers use `0.5rem` (`rounded-lg`) up to `0.75rem` (`rounded-xl`).
- Micro-tags, keyboard shortcuts, and commit pills utilize compact `0.25rem` radii.
- Circular avatars and live status pulse pips use pill/full radius (`9999px`).

## Components

### Buttons
- **Primary**: Background `#2563EB`, text `#FFFFFF`, 1px border `#1D4ED8`, subtle top highlight `inset 0 1px 0 rgba(255, 255, 255, 0.2)`. Hover: `#1D4ED8`. Focus: 2px offset ring with `#2563EB`. Set in Plus Jakarta Sans (`label-md`).
- **Secondary / Neutral**: Background `#FFFFFF`, text `#0F172A`, 1px border `#E2E8F0`. Hover: background `#F8FAFC`, border `#CBD5E1`. Set in Plus Jakarta Sans (`label-md`).
- **Ghost**: Transparent background, text `#334155`. Hover: background `#F1F5F9`, text `#0F172A`.

### Input Fields & Search Bars
- Background `#FFFFFF`, 1px solid border `#E2E8F0`, padding `0.5rem 0.75rem`, text `#0F172A`, placeholder `#94A3B8`. Set in Plus Jakarta Sans (`body-md`).
- Focus: Border `#2563EB`, glow ring `0 0 0 3px rgba(37, 99, 235, 0.12)`.
- Trailing shortcut chips (e.g. `⌘K`) use JetBrains Mono (`code-sm`) inside a `#F1F5F9` background container with `#E2E8F0` border.

### Badges & Technical Chips
- **UI & Category Badges**: Set in Plus Jakarta Sans (`label-sm`).
  - Active: `#ECFDF5` background, `#059669` text, `#A7F3D0` border.
  - Alert: `#FFF7ED` background, `#C2410C` text, `#FFEDD5` border.
- **Technical Metadata / Hash Chips**: Set strictly in JetBrains Mono (`code-sm`), `#F8FAFC` background, `#334155` text, 1px `#E2E8F0` border, `0.125rem 0.375rem` padding.

### Lists & Data Grids
- Row items use `#FFFFFF` background with `#E2E8F0` bottom dividing lines. Hover state transitions row background to `#F8FAFC`.
- Header labels use Plus Jakarta Sans (`label-sm`, uppercase, tracked `0.05em`, color `#64748B`).
- Timestamps (e.g., `2024-05-18T14:32:00Z`), IDs (`#commit-7f41a`), and memory addresses render strictly in JetBrains Mono (`code-sm`).

### Checkboxes & Radios
- Dimensions `16px x 16px`, border `1px solid #CBD5E1`, background `#FFFFFF`. Checkbox corner radius `0.25rem`, radio `9999px`.
- Checked: Background `#2563EB`, border `#2563EB`, white checkmark or center pip.

### Cards & Container Panels
- Background `#FFFFFF`, border `1px solid #E2E8F0`, corner radius `0.5rem`.
- Section titles set in Plus Jakarta Sans (`headline-sm` or `label-md`).
- Integrated code panels, request logs, and telemetry displays inside cards render in `#0F172A` or `#F8FAFC` frames strictly using JetBrains Mono (`code-md` or `code-sm`).